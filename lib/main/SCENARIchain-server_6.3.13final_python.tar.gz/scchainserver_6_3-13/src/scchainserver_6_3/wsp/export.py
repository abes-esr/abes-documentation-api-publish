from typing import Optional, List

from ..api.item import JSendProps
from ..common.svc import Svc
from ..common.utils import StrEnum, check_status


class EScope(StrEnum):
	node = "node"
	net = "net"

class EFormat(StrEnum):
	jar = "jar"
	zip = "zip"
	stream = "stream"

class EMode(StrEnum):
	wspTree = "wspTree"
	flat = "flat"
	rootAndRes = "rootAndRes"

class ELink(StrEnum):
	absolute = "absolute",
	relative = "relative"

class Export(Svc):
	# https://parcours-qua.scenari.ovh/~~chain/web/u/export?cdaction=SendTo&scope=net&format=jar&mode=wspTree&link=absolute&downloadFileName=_web&param=0c1M50ucaMNEkz3NyypH2G&refUris=id%3A0c2M50ucaMNEkz3NyypH2G
	def send_to(self, wsp_code: str, ref_uris: List[str], send_props:JSendProps, scope: EScope = EScope.net, link_filter:Optional[str] = None, mode:EMode = EMode.wspTree,
	            format:EFormat = EFormat.jar, link:ELink = ELink.absolute, include_wsp_metas:bool=True, include_wsp_origin:bool=True,
	            forced_ref_uri_origin:Optional[str]=None)->int:
		qs = {
			"cdaction":"SendTo",
			"param":wsp_code,
			"refUris": "\t".join(ref_uris),
		    "scope": scope,
			"mode": mode,
			"format":format,
			"link":link,
			"includeWspMeta": include_wsp_metas,
			"includeWspOrigin": include_wsp_origin
		}
		if link_filter is not None:
			qs["linkFilter"] = link_filter
		if forced_ref_uri_origin is not None:
			qs["forcedRefUriOrigin"] = forced_ref_uri_origin

		return self._s.put(self._url, params=qs, json=send_props).status_code

	def export(self, wsp_code: str, ref_uris: List[str], scope: EScope = EScope.node, link_filter: Optional[str] = None, mode: EMode = EMode.wspTree, format: EFormat = EFormat.jar,
	           link: ELink = ELink.absolute, include_wsp_metas: bool = True, include_wsp_origin: bool = True, forced_ref_uri_origin: Optional[str] = None) -> bytes:
		qs = {
			"cdaction": "Export",
			"param": wsp_code,
			"refUris": "\t".join(ref_uris),
			"scope": scope,
			"mode": mode,
			"format": format,
			"link": link,
			"includeWspMeta": include_wsp_metas,
			"includeWspOrigin": include_wsp_origin
		}
		if link_filter is not None:
			qs["linkFilter"] = link_filter
		if forced_ref_uri_origin is not None:
			qs["forcedRefUriOrigin"] = forced_ref_uri_origin

		resp =  self._s.put(self._url, params=qs)
		check_status(resp, 200)
		return resp.content