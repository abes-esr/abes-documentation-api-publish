# -*- coding: UTF-8 -*-
import json
import logging
import os
import sys
from typing import Optional, TypedDict, Any

from .appsaas.dptresinstmgr import DptResInstMgr
from .appsaas.instsbackupinplace import InstsBackupInPlace
from .appsaas.instsclustermgr import InstsClusterMgr
from .common.utils import StrEnum
from .core.actlogjson import ActlogJson
from .core.backup import Backup
from .core.backupinplace import BackupInPlace
from .core.executor import Executor
from .core.maintenance import Maintenance
from .core.ping import Ping
from .distrib.actor import Actor
from .distrib.engine import DistribEngine
from .distrib.participant import Participant
from .orient.adminodb import AdminOdb
from .store.assetsctrl import AssetsCtrl
from .store.cidserver import CidServer
from .store.storesquare import StoreSquare
from .urltree.servlets import UrlTreeRenderer, UrlTreeEsSearchServlet
from .wsp.adminwsp import AdminWsp
from .wsp.adminpack import AdminPack
from .wsp.export import Export
from .wsp.importSvc import Import
from .wsp.gen import WspGen
from .wsp.history import History
from .wsp.search import Search
from .core.adminserver import AdminServer
from .core.adminuser import AdminUser


import requests

from .wsp.wspmetaeditor import WspMetaEditor
from .wsp.wspsrc import WspSrc



def _has_arg(arg:str) -> bool:
    if arg not in sys.argv:
        return False
    return True

def _has_args(*args:str) -> bool:
    for arg in args:
        if _has_arg(arg):
            return True
    return False

def _read_arg(arg:str) -> Optional[str]:
    if arg not in sys.argv:
        return None
    pos = sys.argv.index(arg)
    if pos == len(sys.argv) -1:
        return None
    else:
        return sys.argv[pos+1]

def _read_args(*args:str) -> Optional[str]:
    for arg in args:
        val = _read_arg(arg)
        if val is not None:
            return val
    return None

class EPortletName(StrEnum):
    chain = "chain;1",
    depot = "depot;1",
    distrib = "distrib;1",
    saas = "saas;1"

class JChainOpt(TypedDict):
    adminOdb:Optional[bool]
    history:Optional[bool]
    backupInPlace: Optional[bool]
    remoteUsersMgrPortlet: Optional[str]

class JSearchOpt(TypedDict):
    index:str

class JDepotOpt(TypedDict):
    adminOdb:Optional[bool]
    adminPack:Optional[bool]
    search:Optional[JSearchOpt]
    backup: Optional[bool]
    backupInPlace: Optional[bool]
    remoteUsersMgrPortlet: Optional[str]

class JDistribOpt(TypedDict):
    store:Optional[bool]
    backupInPlace: Optional[bool]
    remoteUsersMgrPortlet: Optional[str]

class JPortletConf(TypedDict):
    portlet:EPortletName
    url:str
    opt:Optional[dict[str, Any]]

class JSaasPortalsAccess(TypedDict):
    """ configuration de l'accès aux portals constitués des instances du saas """
    vars:dict[str,str]
    portlets:dict[str,JPortletConf]


class JSaasOpt(TypedDict):
    adminPack:Optional[bool]
    clusterMgr:Optional[bool]
    dptResInstMgr:Optional[bool]
    backupInPlace: Optional[bool]
    remoteUsersMgrPortlet: Optional[str]
    portalsAccess:Optional[JSaasPortalsAccess]


class JPortalConf(TypedDict):
    user:Optional[str]
    password: Optional[str]
    portlets:dict[str,JPortletConf]



class ScPortal:
    def __init__(self, user: str, pw: str, save_conf:any=None):
        self._s:requests.Session = requests.Session() # Session d'interraction avec le portal
        self._s.auth = (user, pw)
        self._portlets: dict[str, Portlet] = {}
        self._saved_conf = save_conf


    @staticmethod
    def _allow_help() -> bool:
        return True

    def help(self):
        """     Affiche cette page d'aide
        """
        print("Cet exécutable permet d'interagir avec un serveur SCENARI. Il vise à aider les")
        print("administrateurs système dans la gestion de leurs serveurs.")
        print("Usage : [executable] [commande] [arguments] [conf] [-v]")
        print(" - [executable] : Le nom de votre exécutable. Il est de forme codeserveur_x_x")
        print(" - [commande] : Voir la liste des commandes disponibles ci-après.")
        print(" - [arguments] : Certaines commandes acceptent des arguments. Consulter leur")
        print("   documentation ci-après")
        print(" - [conf] : paramètres de la configuration du serveur. Valeurs possibles :")
        print("   -u [login] ou --user [login] : surcharge du nom de l'utilisateur")
        print("   -p [password] ou --password [password] : surcharge du mot de passe")
        print("   -c [./maconf.json] ou --conf [./maconf.json] : surcharge de la conf du")
        print("      portail")
        print("   -l ou --local : chargement de la conf système pour un usage depuis le")
        print("      serveur hébergeant le portail SCENARI")
        print(" - [-v] : ajouter -v ou --verbose [level] pour rendre l'exécutable plus bavard.")
        print("   Valeurs de level possibles :")
        print("   -v debug : tous les logs de niveau debug")
        print("   -v info : tous les logs de niveau info (une ligne de log par appel réussi)")
        print("   -v warning : tous les logs de niveau warning")
        print("   -v error : tous les logs de niveau erreur (valeur par défaut). Les logs")
        print("      d'erreur sont également publiées sur le flux stderr.")
        print("   -v none : désactive les logs d'erreur sur la sortie standard (les erreurs")
        print("      restent publiées sur le flux stderr).")
        print("   -v : équivalent à -v info.")
        print("\n")
        print("Liste des commandes disponibles :")
        for method in dir(self):
            if not self._allow(method):
                continue

            print(method)
            if getattr(self, method).__doc__:
                print(getattr(self, method).__doc__)
            else:
                print("    Cette fonction n'est pas documentée.\n")

    @staticmethod
    def _allow_print_conf() -> bool:
        return True

    def print_conf(self, full:bool=False, stream=sys.stdout):
        """    Cette commande permet d'afficher le contenu (simplifié avec les
    URLs uniquement ou complet) de la configuration chargée par l'exécutable.
    Elle permet de récupérer cette configuration pour la modifier (changement 
    d'URL, ajout d'un portlet...)

    Argument(s):
    --full : à utiliser pour afficher la configuration complète (par défaut,
       elle ne contient que les URLs vers les portlets).
"""
        if full:
            print(self._saved_conf, file=stream)
        else:
            conf = {"portlets":{}}
            for code in self._saved_conf["portlets"]:
                conf["portlets"][code] = {"url":self._saved_conf["portlets"][code]["url"]}
            print(conf, file=stream)

    def _allow_backupinplace_pre(self) -> bool:
     for portlet in self._portlets:
         if "backupInPlace" in self[portlet]:
             return True
     return False

    def backupinplace_pre(self, portlet:str=None):
        """    Cette commande prépare chaque portlet à un backup rapide de type "snapshot".
    Les données en RAM sont sérialisées sur disque pour permettre un backup
    cohérent. Après appel de ce service, le répertoire data du portail peut
    être sauvegardé par snapshot. Le portail est accessible en lecture seule
    entre les appels de backupinplace_pre et backupinplace_post

    Argument(s):
    --portlet [chain] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail ayant un service backupinplace.
"""
        if portlet is not None:
            self[portlet].backupInPlace.start_backup()
            logging.info("portlet %s backup in place mode: ready to copy" % portlet)
        else:
            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is not None:
                    # Step 1. Porlet without auth
                    if "backupInPlace" in self[prtlt_cd]:
                        self[prtlt_cd].backupInPlace.start_backup()
                        logging.info("portlet %s backup in place mode: ready to copy" % prtlt_cd)

            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is None:
                    # Step 2. Porlet with auth
                    if "backupInPlace" in self[prtlt_cd]:
                        self[prtlt_cd].backupInPlace.start_backup()
                        logging.info("portlet %s backup in place mode: ready to copy" % prtlt_cd)


    def _allow_backupinplace_post(self) -> bool:
        return self._allow_backupinplace_pre()

    def backupinplace_post(self, strict:bool=False, portlet:str=None):
        """    Cette commande est à appeler après un backup du répertoire data
    par "snapshot". Elle indique aux différents portlets qu'ils peuvent
    réouvrir les accès en écriture.
    Cette commande se termine par des appels de purge de données obsolètes et
    de controle de cohérence (ces appels peuvent être désactivés en utilisant
    l'argument --strict).

    Argument(s):
    --strict : à utiliser pour désactiver les purges de données et contrôle de
        cohérence en fin d'exécution.
    --portlet [chain] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail ayant un service backupinplace.
"""
        if portlet is not None:
            self[portlet].backupInPlace.end_backup()
            logging.info("portlet %s backup in place mode: ended" % portlet)
            if not strict:
                if "assetsCtrl" in self[portlet]:
                    self.assets_gc(portlet=portlet)
                if "store" in self[portlet]:
                    self.store_gc(portlet=portlet)
                if "adminOdb" in self[portlet]:
                    self.odb_checkauto(portlet=portlet)
        else:
            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is None:
                    # Step 1.Porlet with auth
                    try:
                        if "backupInPlace" in self[prtlt_cd]:
                            self[prtlt_cd].backupInPlace.end_backup()
                            logging.info("portlet %s backup in place mode: ended" % prtlt_cd)
                    except Exception as e:
                        logging.error(e)

            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is not None:
                    # Step 2.Porlet without auth
                    try:
                        if "backupInPlace" in self[prtlt_cd]:
                            self[prtlt_cd].backupInPlace.end_backup()
                            logging.info("portlet %s backup in place mode: ended" % prtlt_cd)
                    except Exception as e:
                        logging.error(e)

            if not strict:
                self.assets_gc()
                self.store_gc()
                self.odb_checkauto()

    def _allow_backup_pre(self) -> bool:
        for portlet in self._portlets:
            if isinstance(self[portlet], Chain) and "adminOdb" not in self[portlet]:
                return False
            if isinstance(self[portlet], Depot)  and "backup" not in self[portlet]:
                return False
        return True

    def backup_pre(self, backupid:str, portlet: str):
        """    Copie les fichier de la db interne et verrouille la suppression des blobs
    pour les portlets chains, elle copie un ensemble cohérent des données dans
    un répertoire de backup pour les portlets depot.

    Argument(s):
    --backupid bkp : identifiant du backup (pour un depot uniquement). Si précisé, un
    précédent backup ayant le même identfiant sera supprimé.
    --portlet [chain] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets chain
        et depot du portail.
"""
        if portlet is not None:
            if isinstance(self[portlet], Chain) and "adminOdb" in self[portlet]:
                self[portlet].adminOdb.backup_db()
                logging.info("portlet %s backup: ready to copy" % portlet)
            elif isinstance(self[portlet], Depot) and "backup" in self[portlet]:
                if backupid is not None:
                    if self[portlet].backup.get_backup_info(backup_id=backupid) is not None:
                        self[portlet].backup.delete_backup(backup_id=backupid)
                        self[portlet].backup.wait_for_backup_deleted(backup_id=backupid)
                self[portlet].backup.add_backup(backup_id=backupid)
                self[portlet].backup.wait_for_last_backup_available()
                logging.info("portlet %s backup: ready to copy" % portlet)

        else:
            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is not None:
                    # Step 1. portlet without auth
                    if isinstance(self[prtlt_cd], Chain) and "adminOdb" in self[prtlt_cd]:
                        self[prtlt_cd].adminOdb.backup_db()
                        logging.info("portlet %s backup: ready to copy" % prtlt_cd)
                    elif isinstance(self[prtlt_cd], Depot) and "backup" in self[prtlt_cd]:
                        if backupid is not None:
                            if self[prtlt_cd].backup.get_backup_info(backup_id=backupid) is not None:
                                self[prtlt_cd].backup.delete_backup(backup_id=backupid)
                                self[prtlt_cd].backup.wait_for_backup_deleted(backup_id=backupid)
                        self[prtlt_cd].backup.add_backup(backup_id=backupid)
                        self[prtlt_cd].backup.wait_for_last_backup_available()
                        logging.info("portlet %s backup: ready to copy" % prtlt_cd)
            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is None:
                    # Step 2. portlet with auth
                    if isinstance(self[prtlt_cd], Chain) and "adminOdb" in self[prtlt_cd]:
                        self[prtlt_cd].adminOdb.backup_db()
                        logging.info("portlet %s backup: ready to copy" % prtlt_cd)
                    elif isinstance(self[prtlt_cd], Depot) and "backup" in self[prtlt_cd]:
                        if backupid is not None:
                            if self[prtlt_cd].backup.get_backup_info(backup_id=backupid) is not None:
                                self[prtlt_cd].backup.delete_backup(backup_id=backupid)
                                self[prtlt_cd].backup.wait_for_backup_deleted(backup_id=backupid)
                        self[prtlt_cd].backup.add_backup(backup_id=backupid)
                        self[prtlt_cd].backup.wait_for_last_backup_available()
                        logging.info("portlet %s backup: ready to copy" % prtlt_cd)

    def _allow_backup_post(self) -> bool:
        return self._allow_backup_pre()

    def backup_post(self, backupid:str, portlet:str, strict:bool=None):
        """    Cette commande informe les portlets chain qu'il est à nouveau possible de
    supprimer des blobs du disque. Cette commande se termine par des appels de
    purge de données obsolètes et de controle de cohérence (ces appels peuvent
    être désactivés en utilisant la l'argument --strict)

    Argument(s):
    --backupid bkp : identifiant du backup (pour un depot uniquement). Si précisé, les
    fichiers temporaires à sauvegarder seront supprimés
    --strict : à utiliser pour désactiver les purges de données et contrôle de
        cohérence en fin d'exécution.
    --portlet [chain] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets chain
        et depot du portail.
"""
        if portlet is not None:
            if isinstance(self[portlet], Chain) and "adminOdb" in self[portlet]:
                self[portlet].adminOdb.end_backup()
                logging.info("portlet %s backup mode: ended" % portlet)
            elif isinstance(self[portlet], Depot) and "backup" in self[portlet]:
                if backupid is not None:
                    self[portlet].backup.delete_backup(backup_id=backupid)
                logging.info("portlet %s backup mode: ended" % portlet)

            if not strict:
                if "assetsCtrl" in self[portlet]:
                    self.assets_gc(portlet=portlet)
                if "store" in self[portlet]:
                    self.store_gc(portlet=portlet)
                if "adminOdb" in self[portlet]:
                    self.odb_checkauto(portlet=portlet)
        else:
            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is None:
                    # Step 1. Portlet with auth
                    try:
                        if isinstance(self[prtlt_cd], Chain) and "adminOdb" in self[prtlt_cd]:
                            self[prtlt_cd].adminOdb.end_backup()
                            logging.info("portlet %s backup mode: ended" % prtlt_cd)
                        elif isinstance(self[prtlt_cd], Depot) and "backup" in self[prtlt_cd]:
                            if backupid is not None:
                                self[prtlt_cd].backup.delete_backup(backup_id=backupid)
                            logging.info("portlet %s backup mode: ended" % prtlt_cd)
                    except Exception as e:
                        logging.error(e)
            for prtlt_cd in self._portlets:
                if self[prtlt_cd]._remoteAuthPortlet is not None:
                    # Step 2. Portlet without auth
                    try:
                        if isinstance(self[prtlt_cd], Chain) and "adminOdb" in self[prtlt_cd]:
                            self[prtlt_cd].adminOdb.end_backup()
                            logging.info("portlet %s backup mode: ended" % prtlt_cd)
                        elif isinstance(self[prtlt_cd], Depot) and "backup" in self[prtlt_cd]:
                            if backupid is not None:
                                self[prtlt_cd].backup.delete_backup(backup_id=backupid)
                            logging.info("portlet %s backup mode: ended" % prtlt_cd)
                    except Exception as e:
                        logging.error(e)

            if not strict:
                self.assets_gc()
                self.store_gc()
                self.odb_checkauto()


    def _allow_depot_backup_list(self) -> bool:
        has_depot = False
        for portlet in self._portlets:
            if isinstance(self[portlet], Depot):
                has_depot = True
        return has_depot and self._allow_backup_pre()

    def depot_backup_list(self, portlet:str=None):
        """    Liste les backups disponibles sur les portlets portal.

    Argument(s):
    --portlet [depot] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets depot
        du portail.
"""
        if portlet is not None:
            print(json.dumps(self[portlet].backup.list_backups()))
        else:
            for prtlt_cd in self._portlets:
                if isinstance(self[prtlt_cd], Depot) and "backup" in self[prtlt_cd]:
                    print("Backups du portlet %s: " % prtlt_cd)
                    print(json.dumps(self[prtlt_cd].backup.list_backups()))

    def _allow_depot_backup_restore(self) -> bool:
        return self._allow_depot_backup_list()
    
    def depot_backup_restore(self, portlet:str=None, backupid:str= "~last"):
        """    Restore le backup d'un depot.

    Argument(s):
    --backupid xxx : l'id du backup à restorer. Par défaut, le dernier backup
        disponible est restauré.
    --portlet [depot] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets depot
        du portail.
"""
        if backupid is None:
            backupid = "~last"
        if portlet is not None:
            self[portlet].backup.restore_backup(backup_id=backupid)
            logging.info("Backup %s restored on portlet %s" % (backupid, portlet))
        else:
            for prtlt_cd in self._portlets:
                if isinstance(self[prtlt_cd], Depot) and "backup" in self[prtlt_cd]:
                    self[prtlt_cd].backup.restore_backup(backup_id=backupid)
                    logging.info("Backup %s restored on portlet %s" % (backupid, prtlt_cd))
        print("depot restore backup done. Please RESTART THE SERVER NOW")

    def _allow_depot_backup_delete(self) -> bool:
        return self._allow_depot_backup_list()

    def depot_backup_delete(self, portlet:str=None, backupid:str=None):
        """    Supprime le backup d'un depot. Le paramètre backupid est obligatoire pour
    savoir quel backup supprimer.

    Argument(s):
    --backupid xxx : l'id du backup à restorer.
    --portlet [depot] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets depot
        du portail.
"""
        if portlet is not None:
            self[portlet].backup.delete_backup(backup_id=backupid)
            logging.info("Backup %s deleted on portlet %s" % (backupid, portlet))
        else:
            for prtlt_cd in self._portlets:
                if isinstance(self[prtlt_cd], Depot) and "backup" in self[prtlt_cd]:
                    self[prtlt_cd].backup.delete_backup(backup_id=backupid)
                    logging.info("Backup %s deleted on portlet %s" % (backupid, prtlt_cd))

    @staticmethod
    def _allow_ping() -> bool:
        return True

    def ping(self, portlet:str=None):
        """    Effectue une requête de ping d'un portlet du portail. Cette commande permet
    de tester l'URL, les logins et mots de passe.

    Argument(s):
    --portlet [chain] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail.
"""
        if portlet is not None:
            self[portlet].ping.ping()
            logging.info("portlet %s ping: OK" % portlet)
        else :
            for prtlt_cd in self._portlets:
                self[prtlt_cd].ping.ping()
                logging.info("portlet %s ping: OK" % prtlt_cd)



    def _allow_odb_checkauto(self) -> bool:
        for portlet in self._portlets:
            if "adminOdb" in self[portlet]:
                return True
        return False

    def odb_checkauto(self, portlet:str=None):
        """    Lance un test de cohérence de la base de données interne.

    Argument(s):
    --portlet [chain] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail ayant une base de données interne.
"""
        if portlet is not None:
            self[portlet].adminOdb.check_auto()
            logging.info("portlet %s db check auto: OK" % portlet)
        else:
            for prtlt_cd in self._portlets:
                try:
                    if "adminOdb" in self[prtlt_cd]:
                        self[prtlt_cd].adminOdb.check_auto()
                        logging.info("portlet %s db check auto: OK" % prtlt_cd)
                except Exception as e:
                    logging.error(e)

    def _allow_odb_rebuild(self) -> bool:
        return self._allow_odb_checkauto()

    def odb_rebuild(self, portlet:str=None):
        """     Lance une reconstruction de la base de données interne.

    Argument(s):
    --portlet [chain] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail ayant une base de données interne.
"""
        if portlet is not None:
            self[portlet].adminOdb.rebuild()
            logging.info("portlet %s db rebuild: OK" % portlet)
        else:
            for prtlt_cd in self._portlets:
                if "adminOdb" in self[prtlt_cd]:
                    self[prtlt_cd].adminOdb.rebuild()
                    logging.info("portlet %s db rebuild: OK" % prtlt_cd)


    def _allow_store_gc(self) -> bool:
        for portlet in self._portlets:
            if "store" in self[portlet]:
                return True
        return False

    def store_gc(self, portlet:str=None):
        """    Lance le garbage collector d'un store (stockage de documents d'un depot).

    Argument(s):
    --portlet [depot] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail ayant un store.
"""
        if portlet is not None:
            self[portlet].store.gc()
            logging.info("portlet %s store GC: OK" % portlet)
        else:
            for prtlt_cd in self._portlets:
                if "store" in self[prtlt_cd]:
                    self[prtlt_cd].store.gc()
                    logging.info("portlet %s store GC: OK" % prtlt_cd)


    def _allow_assets_gc(self) -> bool:
        for portlet in self._portlets:
            if "assetsCtrl" in self[portlet]:
                return True
        return False

    def assets_gc(self, portlet:str=None):
        """    Lance le garbage collector des assets (stockage des skins et libs js
    mutualisées).

    Argument(s):
    --portlet [depot] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail ayant un service assets.
"""
        if portlet is not None:
            self[portlet].assetsCtrl.gc()
            logging.info("portlet %s assetsCtrl GC: OK" % portlet)
        else:
            for prtlt_cd in self._portlets:
                if "assetsCtrl" in self[prtlt_cd]:
                    self[prtlt_cd].assetsCtrl.gc()
                    logging.info("portlet %s assetsCtrl GC: OK" % prtlt_cd)

    def _allow_actlogs_purge(self) -> bool:
        return True

    def actlogs_purge(self, days_to_keep:int=365, portlet:str=None):
        """    Lance le garbage collector des actlogs (logs d'accès).

    Argument(s):
    --days_to_keep [365] : nombre de jours d'actlogs à conserver
        (365 par défaut).
    --portlet [depot] : à utiliser pour appeler le service sur un unique
        portlet. Par défaut, la commande s'applique à tous les portlets du
        portail.
"""
        if days_to_keep is None:
            days_to_keep = 365
        if portlet is not None:
            self[portlet].universeActLog.purge_old_logs(days_to_keep)
            logging.info("portlet %s PurgeOldLogs: OK" % portlet)
        else:
            for prtlt_cd in self._portlets:
                self[prtlt_cd].universeActLog.purge_old_logs(days_to_keep)
                logging.info("portlet %s PurgeOldLogs GC: OK" % prtlt_cd)

    def _allow_saas_list_insts(self) -> bool:
        #TODO
        return False

    def saas_list_insts(self):
        logging.error("Not yet implemented")

    def _allow_saas_reload_conf(self) -> bool:
        #TODO
        return False

    def saas_reload_conf(self):
        logging.error("Not yet implemented")


    def call(self):
        if len(sys.argv) > 1:
            cmd = sys.argv[1]
            if self._allow(cmd):
                try:
                    method = getattr(self, cmd)
                    args = {}
                    for arg in method.__annotations__:
                        if method.__annotations__[arg] == bool:
                            args[arg] = _has_arg("--%s" % arg)
                        else:
                            args[arg] =_read_arg("--%s" % arg)
                    method(**args)
                    return
                except Exception as ex:
                    if hasattr(ex, 'message'):
                        logging.error(ex.message)
                    else:
                        logging.error(ex)
                    raise RuntimeError("Unable to execute command %s. Try --help to get help." % cmd)
        raise RuntimeError("Unknown command. Try --help to get help.")

    def _allow(self, method_name:str):
        return "_allow_%s" % method_name in dir(self) and getattr(self, "_allow_%s" % method_name)()


    def add_chain_portlet(self, url:str, code:str = "chain", opt:Optional[JChainOpt]=None):
        if opt is None:
            opt = {}
        self._portlets[code] = Chain(url, self._s, opt)

    def add_depot_portlet(self, url: str, code: str = "depot", opt:Optional[JDepotOpt]=None):
        if opt is None:
            opt = {}
        self._portlets[code] = Depot(url, self._s, opt)

    def add_saas_portlet(self, url: str, code: str = "depotw", opt:Optional[JSaasOpt]=None):
        if opt is None:
            opt = {}
        self._portlets[code] = Saas(url, self._s, opt)

    def add_distrib_portlet(self, url:str, code:str = "distrib", opt:Optional[JDistribOpt]=None):
        if opt is None:
            opt = {}
        self._portlets[code] = Distrib(url, self._s, opt)

    def __getitem__(self, item):
        return self._portlets[item]

    def __contains__(self, item):
        return item in self._portlets


class Portlet:
    def __init__(self, url: str, session: requests.Session, default_exec_frame_code:str="web"):
        self._url:str = url # Url d'accès au portlet
        self._s:requests.Session = session # Session d'interraction avec le portlet
        self._execFrame: str = default_exec_frame_code  # execFrame par défaut
        self._remoteAuthPortlet:str = None # code d'un autre portlet qui porte l'auth

        self.adminServer:AdminServer = AdminServer(self._url, self._execFrame, "adminServer", self._s)
        self.adminUsers:AdminUser = AdminUser(self._url, self._execFrame, "adminUsers", self._s)
        self.executor: Executor = Executor(self._url, self._execFrame, "executor", self._s)
        self.ping:Ping = Ping(self._url, self._execFrame, "ping", self._s)
        self.universeActLog:ActlogJson = ActlogJson(self._url, self._execFrame, "universeActLog", self._s)

    def __contains__(self, item):
        if hasattr(self, item):
            return getattr(self, item)
        else:
            return None



class Chain(Portlet):
    def __init__(self, url, session: requests.Session, opt:JChainOpt):
        super().__init__(url, session)

        self.adminWsp:AdminWsp = AdminWsp(self._url, self._execFrame, "adminWsp", self._s)
        self.adminPack:AdminPack = AdminPack(self._url, self._execFrame, "adminPack", self._s)
        self.export:Export = Export(self._url, self._execFrame, "export", self._s)
        self.maintenance:Maintenance = Maintenance(self._url, self._execFrame, "maintenance", self._s)
        # Suffix Svc car import est un mot réservé en Python
        self.importSvc: Import = Import(self._url, self._execFrame, "import", self._s)
        self.search:Search = Search(self._url, self._execFrame, "search", self._s)
        self.wspGen:WspGen = WspGen(self._url, self._execFrame, "wspGen", self._s)
        self.wspMetaEditor:WspMetaEditor = WspMetaEditor(self._url, self._execFrame, "wspMetaEditor", self._s)
        self.wspSrc:WspSrc = WspSrc(self._url, self._execFrame, "wspSrc", self._s)

        if "adminOdb" in opt and opt["adminOdb"]:
            self.adminOdb:AdminOdb = AdminOdb(self._url, self._execFrame, "adminOdb", self._s)

        if "history" in opt and opt["history"]:
            self.history:History = History(self._url, self._execFrame, "history", self._s)

        if "backupInPlace" in opt and opt["backupInPlace"]:
            self.backupInPlace: BackupInPlace = BackupInPlace(self._url, self._execFrame, "backupInPlace", self._s)

        if "remoteUsersMgrPortlet" in opt:
            self._remoteAuthPortlet = opt["remoteUsersMgrPortlet"]


class Depot(Portlet):
    def __init__(self, url, session: requests.Session, opt:JDepotOpt):
        super().__init__(url, session)
        self.adminTree:UrlTreeRenderer = UrlTreeRenderer(self._url, "adminTree", self._s)
        self.cid:CidServer = CidServer(self._url, self._execFrame, "cid", self._s)
        self.maintenance:Maintenance = Maintenance(self._url, self._execFrame, "maintenance", self._s)
        self.store:StoreSquare = StoreSquare(self._url, self._execFrame, "store", self._s)
        self.tree:UrlTreeRenderer = UrlTreeRenderer(self._url, "tree", self._s)

        if "adminOdb" in opt and opt["adminOdb"]:
            self.adminOdb: AdminOdb = AdminOdb(self._url, self._execFrame, "adminOdb", self._s)

        if "adminPack" in opt and opt["adminPack"]:
            self.adminPack:AdminPack = AdminPack(self._url, self._execFrame, "adminPack", self._s)

        if "assets" in opt and opt["assets"]:
            self.assetsCtrl: AssetsCtrl = AssetsCtrl(self._url, self._execFrame, "assetsCtrl", self._s)

        if "backup" in opt and opt["backup"]:
            self.backup:Backup = Backup(self._url, self._execFrame, "backup", self._s)

        if "backupInPlace" in opt and opt["backupInPlace"]:
            self.backupInPlace: BackupInPlace = BackupInPlace(self._url, self._execFrame, "backupInPlace", self._s)

        if "search" in opt and opt["search"] is not None:
            self.search:UrlTreeEsSearchServlet  = UrlTreeEsSearchServlet(self._url, "search", self._s, index=opt["search"]["indexes"][0])

        if "remoteUsersMgrPortlet" in opt:
            self._remoteAuthPortlet = opt["remoteUsersMgrPortlet"]

class Saas(Portlet):
    def __init__(self, url, session: requests.Session, opt:JSaasOpt):
        super().__init__(url, session)
        self._portalsAccess:Optional[JSaasPortalsAccess] = opt["portalsAccess"]
        self.backupInstsInPlace: InstsBackupInPlace = InstsBackupInPlace(self._url, self._execFrame, "backupInstsInPlace", self._s)

        self.maintenance:Maintenance = Maintenance(self._url, self._execFrame, "maintenance", self._s)

        if "adminPack" in opt and opt["adminPack"]:
            self.adminPack:AdminPack = AdminPack(self._url, self._execFrame, "adminPack", self._s)

        if "backupInPlace" in opt and opt["backupInPlace"]:
            self.backupInPlace: BackupInPlace = BackupInPlace(self._url, self._execFrame, "backupInPlace", self._s)

        if "clusterMgr" in opt and opt["clusterMgr"]:
            self.instsClusterMgr: InstsClusterMgr = InstsClusterMgr(self._url, self._execFrame, "instsClusterMgr", self._s)

        if "dptResInstMgr" in opt and opt["dptResInstMgr"]:
            self.dptResInstMgr: DptResInstMgr = DptResInstMgr(self._url, self._execFrame, "dptResInstMgr", self._s)

        if "remoteUsersMgrPortlet" in opt:
            self._remoteAuthPortlet = opt["remoteUsersMgrPortlet"]

    def get_portal(self, user:str=None, pw=None, args:dict[str:Any]=None) -> ScPortal:
        if self._portalsAccess is None:
            raise ValueError("portalsAccess conf is None. Unable to create a portal for saas instances")
        if args is None:
            args = {}
        variables = {**self._portalsAccess["vars"], **args}
        conf = Saas._format_prop(self._portalsAccess["portlets"], variables)

        portal = ScPortal(user=user, pw=pw)
        for code in conf:
            portlet: JPortletConf = conf[code]
            if portlet["portlet"] == EPortletName.chain.value:
                portal.add_chain_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
            elif portlet["portlet"] == EPortletName.depot.value:
                portal.add_depot_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
            elif portlet["portlet"] == EPortletName.distrib.value:
                portal.add_distrib_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
            elif portlet["portlet"] == EPortletName.saas.value:
                portal.add_saas_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
            else:
                logging.error("unknown portlet %s" % portlet)
                sys.exit(1)

        return portal

    @staticmethod
    def _format_prop(prop: Any, variables: dict):
        if type(prop) is dict:
            formatted_props = {}
            for key in prop:
                formatted_props[key] = Saas._format_prop(prop[key], variables)
            return formatted_props
        elif type(prop) is list:
            formatted_props = []
            for val in prop:
                formatted_props.append(Saas._format_prop(val, variables))
            return formatted_props
        elif type(prop) is str:
            return prop.format(vars=variables)
        else:
            return prop


class Distrib(Portlet):
    def __init__(self, url, session: requests.Session, opt:JDistribOpt):
        super().__init__(url, session, default_exec_frame_code="admin")
        self._runExecFrame: str = "run"
        self._runSession:requests.Session = requests.Session()
        self.distribEngine = DistribEngine(self._url, self._runExecFrame, "distribEngine", self._runSession)
        self.participant = Participant(self._url, self._runExecFrame, "participant", self._runSession)
        self.actor = Actor(self._url, self._runExecFrame, "actor", self._runSession)

        if "store" in opt and opt["store"]:
            self.store:StoreSquare = StoreSquare(self._url, self._execFrame, "store", self._s)

        if "backupInPlace" in opt and opt["backupInPlace"]:
            self.backupInPlace: BackupInPlace = BackupInPlace(self._url, self._execFrame, "backupInPlace", self._s)

        if "remoteUsersMgrPortlet" in opt:
            self._remoteAuthPortlet = opt["remoteUsersMgrPortlet"]


def new_portal(system_conf:bool=False, overridden_conf_file:Optional[str]=None, override_props:Optional[Any]=None):
    conf_file:str=os.path.join(os.path.dirname(__file__), "system_default_conf.json" if system_conf else "public_default_conf.json")
    with open(conf_file, "r") as file:
        conf:JPortalConf = json.load(file)
    if overridden_conf_file is not None:
        with open(overridden_conf_file, "r") as file:
            overridden_conf:JPortalConf = json.load(file)
        conf = __override_prop(conf, overridden_conf)

    if override_props is not None:
        conf = __override_prop(conf, override_props)

    user = conf["user"] if "user" in conf else None
    pw = conf["password"] if "password" in conf else None
    portal = ScPortal(user=user, pw=pw, save_conf=conf)

    if("portlets" not in conf):
        logging.error("Error : no portlets found in portal conf.")
        sys.exit(1)

    for code in conf["portlets"]:
        portlet:JPortletConf = conf["portlets"][code]
        if portlet["portlet"] == EPortletName.chain.value:
            portal.add_chain_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
        elif portlet["portlet"] == EPortletName.depot.value:
            portal.add_depot_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
        elif portlet["portlet"] == EPortletName.distrib.value:
            portal.add_distrib_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
        elif portlet["portlet"] == EPortletName.saas.value:
            portal.add_saas_portlet(url=portlet["url"], code=code, opt=portlet["opt"])
        else:
            logging.error("unknown portlet %s" % portlet)
            sys.exit(1)

    return portal

def __override_prop(prop, override):
    if prop is None or type(prop) is not dict:
        prop = {}

    for code in override:
        if type(override[code]) is dict:
            prop[code] = __override_prop({} if code not in prop else prop[code], override[code])
        else:
            prop[code] = override[code]
    return prop

def __main():
    try:
        user = _read_args("-u", "--user")
        pw = _read_args("-p", "--password")
        conf = _read_args("-c", "--conf")
        local = _has_args("-l", "--local")
        verbose = _read_args("-v", "--verbose")
        doc = _has_args("-h", "--help")

        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')

        error_handler = logging.StreamHandler(stream=sys.stderr)
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(formatter)
        logging.getLogger().setLevel(logging.DEBUG)

        if verbose == "debug":
            error_handler.setLevel(logging.DEBUG)
        elif verbose == "info":
            error_handler.setLevel(logging.INFO)
        elif verbose == "warning":
            error_handler.setLevel(logging.WARNING)
        elif verbose == "error":
            error_handler.setLevel(logging.ERROR)
        elif _has_args("-v", "--verbose"):
            error_handler.setLevel(logging.INFO)
        else:
            error_handler.setLevel(logging.ERROR)

        if verbose != "none":
            logging.getLogger().addHandler(error_handler)

        override_conf ={}
        if user is not None:
            override_conf["user"] = user
        if pw is not None:
            override_conf["password"] = pw

        portal = new_portal(system_conf=local, overridden_conf_file=conf, override_props=override_conf)
        if doc:
            portal.help()
        else:
            portal.call()
    except Exception as ex:
        if hasattr(ex, 'message'):
            logging.error(ex.message)
        else:
            logging.error(ex)
        sys.exit(1)

if __name__ == '__main__':
    __main()
